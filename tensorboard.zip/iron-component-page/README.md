
<!---

This README is automatically generated from the comments in these files:
iron-component-page.html

Edit those files, and our readme bot will duplicate them over here!
Edit this file, and the bot will squash your changes :)

The bot does some handling of markdown. Please file a bug if it does the wrong
thing! https://github.com/PolymerLabs/tedium/issues

-->

[![Build status](https://travis-ci.org/PolymerElements/iron-component-page.svg?branch=master)](https://travis-ci.org/PolymerElements/iron-component-page)

_[Demo and API docs](https://elements.polymer-project.org/elements/iron-component-page)_


##&lt;iron-component-page&gt;

Loads Polymer element and behavior documentation using
[Hydrolysis](https://github.com/PolymerLabs/hydrolysis) and renders a complete
documentation page including demos (if available).


